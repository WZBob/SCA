/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.    
 */
package org.apache.tuscany.sca.itest.builder;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import javax.wsdl.Definition;
import javax.wsdl.Port;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.soap.SOAPAddress;
import javax.wsdl.extensions.soap12.SOAP12Address;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLWriter;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLStreamWriter;

import org.apache.tuscany.sca.assembly.Binding;
import org.apache.tuscany.sca.assembly.Component;
import org.apache.tuscany.sca.assembly.ComponentReference;
import org.apache.tuscany.sca.assembly.ComponentService;
import org.apache.tuscany.sca.assembly.Composite;
import org.apache.tuscany.sca.assembly.Contract;
import org.apache.tuscany.sca.assembly.Endpoint;
import org.apache.tuscany.sca.assembly.EndpointReference;
import org.apache.tuscany.sca.assembly.Implementation;
import org.apache.tuscany.sca.assembly.Reference;
import org.apache.tuscany.sca.assembly.Service;
import org.apache.tuscany.sca.assembly.impl.EndpointImpl;
import org.apache.tuscany.sca.assembly.impl.EndpointReferenceImpl;
import org.apache.tuscany.sca.binding.ws.WebServiceBinding;
import org.apache.tuscany.sca.contribution.processor.ProcessorContext;
import org.apache.tuscany.sca.monitor.Problem;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;

/**
 * Static utility methods for use by test cases.
 * 
 * @version $Rev: 955601 $ $Date: 2010-06-17 06:55:03 -0700 (Thu, 17 Jun 2010) $
 */
public class TestUtils {

    protected static void checkProblems(CustomCompositeBuilder customBuilder) throws Exception {
        boolean problems = false;
        for (Problem problem : customBuilder.getMonitor().getProblems()) {
            if (problem.getCause() != null) {
                problem.getCause().printStackTrace();
            }
            if (problem.getSeverity() == Problem.Severity.ERROR){
                problems = true;
            }
        }
        assert !problems;
    }

    protected static String getPortAddress(Port port) {
        Object ext = port.getExtensibilityElements().get(0);
        String returnAddress = null;
        if (ext instanceof SOAPAddress) {
            returnAddress = ((SOAPAddress)ext).getLocationURI();
        }
        if (ext instanceof SOAP12Address) {
            returnAddress = ((SOAP12Address)ext).getLocationURI();
        }
        
        returnAddress = returnAddress.substring(returnAddress.indexOf("//") + 2);
        returnAddress = returnAddress.substring(returnAddress.indexOf("/"));
        
        return returnAddress;
    }

    protected static Component getComponent(Composite composite, String name) {
        for (Component component : composite.getComponents()) {
            if (name.equals(component.getName())) {
                return component;
            }
            // process implementation composites recursively
            Implementation impl = component.getImplementation();
            if (impl instanceof Composite) {
                Component comp = getComponent((Composite)impl, name);
                if (comp != null) {
                    return comp;
                }
            }
        }
        return null;
    }

    protected static Composite getComposite(Composite composite, QName name) {
        if (name.equals(composite.getName())) {
            return composite;
        }
        for (Component component : composite.getComponents()) {
            // process implementation composites recursively
            Implementation impl = component.getImplementation();
            if (impl instanceof Composite) {
                Composite comp = getComposite((Composite)impl, name);
                if (comp != null) {
                    return comp;
                }
            }
        }
        return null;
    }

    protected static void printResults(CustomCompositeBuilder customBuilder) throws Exception {
        for (Problem problem : customBuilder.getMonitor().getProblems()) {
            if (problem.getCause() != null) {
                problem.getCause().printStackTrace();
            }
        }
        Composite domainComposite = customBuilder.getDomainComposite();
        printComposite(domainComposite, customBuilder);
    }

    private static void printComposite(Composite composite, CustomCompositeBuilder customBuilder) throws Exception {
        // process implementation composites recursively
        for (Component component : composite.getComponents()) {
            Implementation implementation = component.getImplementation();
            if (implementation instanceof Composite) {
                printComposite((Composite)implementation, customBuilder);
            }
        }

        // write out the SCDL
        writeSCDL(composite, customBuilder);

        // find all the component service and reference bindings     
        for (Component component : composite.getComponents()) {
            for (ComponentService componentService : component.getServices()) {
                for (Binding binding : componentService.getBindings()) {
                    if (binding instanceof WebServiceBinding) {
                        writeWSDL(component, componentService, ((WebServiceBinding)binding).getGeneratedWSDLDocument());
                    }
                }
            }
            for (ComponentReference componentReference : component.getReferences()) {
                for (Binding binding : componentReference.getBindings()) {
                    if (binding instanceof WebServiceBinding) {
                        writeWSDL(component, componentReference, ((WebServiceBinding)binding).getGeneratedWSDLDocument());
                    }
                }
            }
        }

        // find all the composite service and reference bindings     
        for (Service service : composite.getServices()) {
            for (Binding binding : service.getBindings()) {
                if (binding instanceof WebServiceBinding) {
                    writeWSDL(null, service, ((WebServiceBinding)binding).getGeneratedWSDLDocument());
                }
            }
        }
        for (Reference reference : composite.getReferences()) {
            for (Binding binding : reference.getBindings()) {
                if (binding instanceof WebServiceBinding) {
                    writeWSDL(null, reference, ((WebServiceBinding)binding).getGeneratedWSDLDocument());
                }
            }
        }
    }

    private static void writeSCDL(Composite composite, CustomCompositeBuilder customBuilder) throws Exception {
        // Print out a composite
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        XMLStreamWriter writer = customBuilder.getOutputFactory().createXMLStreamWriter(bos);
        customBuilder.getModelProcessor().write(composite, writer, new ProcessorContext());
        
        // Parse and write again to pretty format it
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document = documentBuilder.parse(new ByteArrayInputStream(bos.toByteArray()));
        OutputFormat format = new OutputFormat();
        format.setIndenting(true);
        format.setIndent(2);
        XMLSerializer serializer = new XMLSerializer(System.out, format);
        System.out.println("-->Runtime SCDL model for composite " + composite.getName());
        serializer.serialize(document);
    }

    private static void writeWSDL(Component component, Contract contract, Definition definition) {
        if (definition == null) {
            System.out.println("-->No generated WSDL for " + (component != null ? component.getName() : "") + "/" + contract.getName());
        } else {
            try {
                System.out.println("-->Generated WSDL for " + (component != null ? component.getName() : "") + "/" + contract.getName());
                WSDLWriter writer =  WSDLFactory.newInstance().newWSDLWriter();
                writer.writeWSDL(definition, System.out);
            } catch (WSDLException e) {
                // ignore
            }
        }
    }
    
    protected static void writeWSDL(Definition definition) {
        try {
            WSDLWriter writer =  WSDLFactory.newInstance().newWSDLWriter();
            writer.writeWSDL(definition, System.out);
        } catch (WSDLException e) {
            // ignore
        }
    }
    
    protected static String printStructure(Composite composite, String indent){
        String structure = "";
        for (Component component : composite.getComponents()){
            structure += indent + "Component URI - " + component.getURI() + "\n";
            
            // recurse for composite implementations
            Implementation implementation = component.getImplementation();
            if (implementation instanceof Composite) {
                structure += printStructure((Composite)implementation, indent + "  ");
            }
            
            for (Service service : component.getServices()){
                for (Endpoint endpoint : service.getEndpoints()){
                    structure += indent + ((EndpointImpl)endpoint).toStringWithoutHash() + " " + endpoint.getBinding().getClass().getName() + "\n";
                }
            }
            for (Reference reference : component.getReferences()){
                for (EndpointReference endpointReference : reference.getEndpointReferences()){
                    structure += indent + ((EndpointReferenceImpl)endpointReference).toStringWithoutHash() + " " + endpointReference.getBinding().getClass().getName() + "\n";
                }
            }
        }
        return structure;
    }    
/*    
    protected static String printEndpoints(Composite composite){
        return printEndpoints(composite, "");
    }
    
    protected static String printEndpoints(Composite composite, String indent){
        
        String buffer = ""; 
        
        for (Component component : composite.getComponents()) {
            buffer += indent + "Component - " + component.getName() + "\n";
            
            // print component service endpoints
            for (ComponentService componentService : component.getServices()) {
                buffer += indent + "Service - " + componentService.getName() + "\n";
                for (Endpoint endpoint : componentService.getEndpoints()) {
                    if (endpoint.getBinding() != null){
                        buffer += printEndpoint(endpoint, indent);
                    }
                }
            }
            
            for (ComponentReference componentReference : component.getReferences()) {
                buffer += indent + "Reference - " + componentReference.getName() + "\n";
                for (EndpointReference endpointReference : componentReference.getEndpointReferences()) {
                    buffer += printEndpointReference(endpointReference, indent);
                }
            }
            
            // process implementation composites recursively
            Implementation implementation = component.getImplementation();
            if (implementation instanceof Composite) {
                buffer += indent + "Component - " + component.getName() + " has composite impl" + "\n";
                buffer += printEndpoints((Composite)implementation, indent + "   ");
            }
        }
        
        return buffer;        
    }
    
    protected static String printEndpoint(Endpoint endpoint, String indent){
        String buffer = ""; 
        
        buffer += indent + " Endpoint - Component: " + endpoint.getComponent().getName() +"\n";
        buffer += indent + "            Service:   " + endpoint.getService().getName() +"\n";
        buffer += indent + "            Binding:   " + endpoint.getBinding().getName() +"\n";
        
        return buffer;
    }
    
    protected static String printEndpointReference(EndpointReference endpointReference, String indent){
        String buffer = ""; 
        
        buffer += indent + " EndpointReference - Component:        " + endpointReference.getComponent().getName() +"\n";
        buffer += indent + "                     Reference:        " + endpointReference.getReference().getName() +"\n";
        if (endpointReference.getTargetEndpoint() != null){
            buffer += indent + "                     Wired:            " +"\n";
            buffer += indent + "                       Target:         " + endpointReference.getTargetEndpoint().getComponent().getName()+"\n";
            if (endpointReference.getTargetEndpoint() != null && 
                endpointReference.getTargetEndpoint().isUnresolved() == false){
                buffer += indent + "                       Binding:        " + endpointReference.getBinding().getName() +"\n";
                buffer += indent + "                       TargetEndpoint: " + endpointReference.getTargetEndpoint().getBinding().getName()+"\n";
            } else {
                buffer += indent + "                       Unresolved:     " +"\n";
            }
        } else {
            buffer += indent + "                     NonWired:         " +"\n";
        }
        
        return buffer;
    }    
*/
}
